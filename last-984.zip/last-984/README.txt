Please see the documentation in the "doc" directory.

* Installation & general info: doc/last.txt
* Usage: start with doc/last-tutorial.txt
